import java.util.Scanner;
import java.sql.*;

class DatabaseMenuAccess {
    //Empty constructor
    public DatabaseMenuAccess(){}
    //This method perform the functions of the menu option chosen
     public void run(){
        int option;

        do {
            menuDisplay();
            option = menuChoice();

            switch (option){
                case 1:
                    System.out.println("Enter book: ");
                    enterBook();
                    break;

                case 2:
                    System.out.println("Update book: ");
                    updateBook();
                    break;

                case 3:
                    System.out.println("Delete book: ");
                    deleteBook();
                    break;

                case 4:
                    System.out.println("Search books: ");
                    searchBook();
                    break;

                case 0:
                    System.out.println("Exit");
                    break;

                default:
                    System.out.println("Invalid option");
                    break;
            }
        }
        while (option != 0);
    }
    //Displays all the menu options
    private void menuDisplay(){
        System.out.println("\nSelect what you want to do: \n");
        System.out.println("1. Enter book");
        System.out.println("2. Update book");
        System.out.println("3. Delete book");
        System.out.println("4. Search books");
        System.out.println("0. Exit");
    }
    //Allows the user to input their menu option
    private int menuChoice(){
        int option;
        System.out.println("Please enter your choice: ");
        Scanner input = new Scanner(System.in);
        option = input.nextInt();
        return option;
    }
    //Displays what the user is allowed to update in the database
    private void updateBookDisplay(){
        System.out.println("\nPlease select what you would like to update.\n");
        System.out.println("1. Title");
        System.out.println("2. Author");
        System.out.println("3. Quantity");
        System.out.println("4. Cancel");
    }
    //This method will get the last id number in the database then add 1 to the id number for the next row added
    private int getLastID(){
        int lastID = 0;

        try(
                Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ebookstore?useSSL=false" ,
                        "myuser" ,
                        "chetty" );

                Statement stmn = conn.createStatement()
                ){
            String idLast = "select max(id) as max_id from books";
            ResultSet lastIdRset = stmn.executeQuery(idLast);

            while (lastIdRset.next()){
                lastID = lastIdRset.getInt("max_id") + 1;
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return lastID;
    }
    //This method will allow the user to add a new book to the database
    private void enterBook(){
        try (
                Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ebookstore?useSSL=false" ,
                        "myuser" ,
                        "chetty" );

                Statement stmn = conn.createStatement()
                ){
            Scanner input = new Scanner(System.in);

            System.out.println("Enter the book title: ");
            String bookTitle = input.nextLine();
            System.out.println("Enter the book author: ");
            String bookAuthor = input.nextLine();
            System.out.println("Enter the book quantity: ");
            int bookQty = input.nextInt();

            String sqlInsert = "insert into books " + "(id, title, author, qty) "
                    +"values("+getLastID()+", '"+bookTitle+"', '"+bookAuthor+"', "+bookQty+")";
            System.out.println("The SQL query is: " + sqlInsert);
            int countInserted = stmn.executeUpdate(sqlInsert);
            System.out.println(countInserted + " records inserted.\n");

            String strSelect = "select * from books";
            ResultSet rset = stmn.executeQuery(strSelect);

            while (rset.next()){
                System.out.println(rset.getInt("id") + ", "
                        + rset.getString("title") + ", "
                        + rset.getString("author") + ", "
                        + rset.getInt("qty"));
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }

    }
    /*This method will allow the user to update the databases records
    The book I.D will be used to identify the book to be updated in the database
     */
    private void updateBook(){
        try (
                Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ebookstore?useSSL=false" ,
                        "myuser" ,
                        "chetty" );

                Statement stmn = conn.createStatement()
        ){
            int option;

            String sqlUpdate;
            int bookID;
            int countUpdated;
            int compareTo = 0;

            //Display the books currently in the database
            String strDisplayTable = "select * from books";
            ResultSet rsetDisplay = stmn.executeQuery(strDisplayTable);

            while (rsetDisplay.next()){
                System.out.println(rsetDisplay.getInt("id") + ", "
                        + rsetDisplay.getString("title") + ", "
                        + rsetDisplay.getString("author") + ", "
                        + rsetDisplay.getInt("qty"));
            }

            Scanner input = new Scanner(System.in);

            do {
                updateBookDisplay();
                option = menuChoice();

                switch (option){
                    //Update the books title
                    case 1:
                        System.out.println("Enter the book I.D of the book that you want updated: ");
                        bookID = input.nextInt();

                        //New line for nextInt to consume
                        input.nextLine();

                        String checkTitleID = "select id from books";
                        ResultSet TitleIdCompare = stmn.executeQuery(checkTitleID);

                        while (TitleIdCompare.next()){
                            compareTo = TitleIdCompare.getInt("id");
                        }
                        //This will check if the ID number entered is in the database
                        if (compareTo != bookID){
                            System.out.println("Invalid ID\n");
                        }
                        else {
                            System.out.println("What do you want the updated title to be? ");
                            String newTitle = input.nextLine();

                            sqlUpdate = String.format("update books set title = '%s' where id =%d",newTitle,bookID);
                            System.out.println("The SQL query is: " + sqlUpdate);
                            countUpdated = stmn.executeUpdate(sqlUpdate);
                            System.out.println(countUpdated + " records updated.\n");
                            break;
                        }
                        break;
                    //Update the books author
                    case 2:
                        System.out.println("Enter the book I.D of the book that you want updated: ");
                        bookID = input.nextInt();

                        input.nextLine();

                        String checkAuthorID =  "select id from books";
                        ResultSet AuthorIdCompare = stmn.executeQuery(checkAuthorID);

                        while (AuthorIdCompare.next()){
                            compareTo = AuthorIdCompare.getInt("id");
                        }

                        if (compareTo != bookID){
                            System.out.println("Invalid ID\n");
                        }
                        else {
                            System.out.println("What do you want the updated author to be? ");
                            String newAuthor = input.nextLine();


                            sqlUpdate = String.format("update books set author = '%s' where id =%d",newAuthor,bookID);
                            System.out.println("The SQL query is: " + sqlUpdate);
                            countUpdated = stmn.executeUpdate(sqlUpdate);
                            System.out.println(countUpdated + " records updated.\n");
                            break;
                        }
                        break;
                    //Update the books quantity
                    case 3:
                        System.out.println("Enter the book I.D of the book that you want updated: ");
                        bookID = input.nextInt();

                        input.nextLine();

                        String checkQtyID =  "select id from books";
                        ResultSet QtyIdCompare = stmn.executeQuery(checkQtyID);

                        while (QtyIdCompare.next()){
                            compareTo = QtyIdCompare.getInt("id");
                        }
                        if (compareTo != bookID){
                            System.out.println("Invalid ID\n");
                        }

                        else {
                            System.out.println("What do you want the updated quantity to be? ");
                            String newQty = input.next();

                            sqlUpdate = "update books set qty ="+newQty+" where id"+"="+bookID;
                            System.out.println("The SQL query is: " + sqlUpdate);
                            countUpdated = stmn.executeUpdate(sqlUpdate);
                            System.out.println(countUpdated + " records updated.\n");
                            break;
                        }
                        break;
                    case 4:
                        System.out.println("Exit");
                        break;
                    case 5:
                        System.out.println("Invalid entry");
                        break;

                }
                String strSelect = "select * from books";
                ResultSet rset = stmn.executeQuery(strSelect);

                while (rset.next()){
                    System.out.println(rset.getInt("id") + ", "
                            + rset.getString("title") + ", "
                            + rset.getString("author") + ", "
                            + rset.getInt("qty"));
                }
            }
            while (option != 4);

        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
    }
    /*This method will allow the user to delete a row from the database
    The user will be required to enter the book ID only
     */
    private void deleteBook(){
        try (
                Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ebookstore?useSSL=false" ,
                        "myuser" ,
                        "chetty" );

                Statement stmn = conn.createStatement()
        ){
            String strDisplayTable = "select * from books";
            ResultSet rsetDisplay = stmn.executeQuery(strDisplayTable);

            while (rsetDisplay.next()){
                System.out.println(rsetDisplay.getInt("id") + ", "
                        + rsetDisplay.getString("title") + ", "
                        + rsetDisplay.getString("author") + ", "
                        + rsetDisplay.getInt("qty"));
            }

            System.out.println("\nEnter the book I.D of the book you want deleted: ");
            Scanner input = new Scanner(System.in);
            int deleteBook = input.nextInt();
            String sqlDelete = "delete from books where id"+"="+deleteBook;
            System.out.println("The SQL query is: " + sqlDelete);
            int countDeleted = stmn.executeUpdate(sqlDelete);
            System.out.println(countDeleted + " record/s deleted.\n");

            String strSelect = "select * from books";
            ResultSet rset = stmn.executeQuery(strSelect);

            if (rset.next()){

                do {
                    System.out.println(rset.getInt("id") + ", "
                            + rset.getString("title") + ", "
                            + rset.getString("author") + ", "
                            + rset.getInt("qty"));
                }
                while (rset.next());
            }
            else {
                System.out.println("Invalid ID number entered");
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
    }
    /*This method will display all information for a book chosen by the user.
    The user will be required to enter the books title only
    */
    private void searchBook(){
        try (
                Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/ebookstore?useSSL=false" ,
                        "myuser" ,
                        "chetty" );

                Statement stmn = conn.createStatement()
        ){
            System.out.println("Enter the books title: ");
            Scanner input = new Scanner(System.in);
            String bookTitle = input.nextLine().toUpperCase();
            String strSelect = String.format("select * from books where title ='%s'",bookTitle);
            ResultSet rset = stmn.executeQuery(strSelect);

            //This will display an error message if the book ID is not found
            if (rset.next()){

                do {
                    System.out.println(rset.getInt("id") + ", "
                            + rset.getString("title") + ", "
                            + rset.getString("author") + ", "
                            + rset.getInt("qty"));
                }
                while (rset.next());
            }
            else {
                System.out.println("Invalid title entered");
            }

        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
    }
}

public class BookStore {
    public static void main(String[] args) {
        //Instantiates new DatabaseMenuAccess object and runs it
        DatabaseMenuAccess m = new DatabaseMenuAccess();
        m.run();
    }
}

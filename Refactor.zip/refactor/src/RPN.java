import java.util.Scanner;

class StackNode {
    private StackNode bottomOfStack;
    private double stackData;

    StackNode(double stackData, StackNode bottomOfStack) {
        this.setStackData(stackData);
        this.setBottomOfStack(bottomOfStack);
    }

    StackNode getBottomOfStack() {
        return bottomOfStack;
    }

    private void setBottomOfStack(StackNode bottomOfStack) {
        this.bottomOfStack = bottomOfStack;
    }

    double getStackData() {
        return stackData;
    }

    private void setStackData(double stackData) {
        this.stackData = stackData;
    }
}

class RPN {
    private String command;
    private StackNode topOfStack;

    private RPN(String command) {
        topOfStack = null;
        this.command = command;
    }

    private void intoStack(double new_data) {
        StackNode new_node;
        new_node = new StackNode(new_data, topOfStack);
        topOfStack = new_node;
    }

    private double outOfStack() {
        var top_data = topOfStack.getStackData();
        topOfStack = topOfStack.getBottomOfStack();
        return top_data;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }

    private double calculate() {
        double a, b;
        int j;

        for(var i = 0; i < command.length( ); i++) {
            // if it's a digit
            if(Character.isDigit(command.charAt(i))) {
                double number;

                // calculate a string of the number
                StringBuilder temp = new StringBuilder();
                for(j = 0; (j < 100) && (Character.isDigit(command.charAt(i)) || (command.charAt(i) == '.')); j++, i++) {
                    temp.append(command.charAt(i));
                }

                // convert to double and add to the stack
                number = Double.parseDouble(temp.toString());
                intoStack(number);
            } else if(command.charAt(i) == '+') {
                b = outOfStack( );
                a = outOfStack( );
                intoStack(a + b);
            } else if(command.charAt(i) == '-') {
                b = outOfStack( );
                a = outOfStack( );
                intoStack(a - b);
            } else if(command.charAt(i) == '*') {
                b = outOfStack( );
                a = outOfStack( );
                intoStack(a * b);
            } else if(command.charAt(i) == '/') {
                b = outOfStack( );
                a = outOfStack( );
                intoStack(a / b);
            }
            else if(command.charAt(i) == '^') {
                b = outOfStack( );
                a = outOfStack( );
                intoStack(Math.pow(a, b));
            } else if(command.charAt(i) != ' ') {
                throw new IllegalArgumentException( );
            }
        }

        var val = outOfStack( );

        if(topOfStack != null) {
            throw new IllegalArgumentException( );
        }

        return val;
    }

    /* main method */
    public static void main(String[] args) {
        try {
            while(true) {
                var in = new Scanner(System.in);
                System.out.println("Enter RPN expression or \"quit\".");
                var line = in.nextLine( );
                if(line.equals("quit")) {
                    break;
                } else {
                    RPN calc;
                    calc = new RPN(line);
                    System.out.printf("Answer is %f\n", calc.calculate( ));
                }
            }

        }catch (Exception e){
            System.out.println("Invalid");
        }
    }
}